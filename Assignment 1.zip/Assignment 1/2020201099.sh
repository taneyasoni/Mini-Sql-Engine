#!/bin/bash
python 2020201099_minisql.py "$@"
